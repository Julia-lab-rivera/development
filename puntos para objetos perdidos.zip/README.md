# Módulo de Puntos - Objetos Perdidos (Sergio)

Implementa la historia de usuario:

> Como estudiante de la Sergio, quiero ganar puntos al ver o registrar
> objetos y recibir aún más puntos cuando devuelvo un objeto perdido de
> gran valor, para poder reclamar recompensas en el futuro.

Este módulo está pensado para integrarse con el resto del proyecto
`objetos-perdidos` (JavaFX + Maven), que también incluirá módulos de:
- Reporte de objetos perdidos/encontrados
- Fotos de los objetos
- Control de usuarios que ingresan a la app (login / sesiones)

## Estructura (siguiendo el `pom.xml` del proyecto)

El `pom.xml` define `<sourceDirectory>src</sourceDirectory>` (no el
`src/main/java` estándar de Maven) y espera una clase `Main` en el
**paquete por defecto** (`<mainClass>Main</mainClass>`). Por eso este
módulo NO trae su propio `Main.java`; en vez de eso trae `DemoPuntos.java`
como punto de entrada de prueba, para no chocar con el `Main` real de
JavaFX que arma el resto del equipo.

```
objetos-perdidos/
├── pom.xml
└── src/
    ├── back/
    │   └── puntos/
    │       ├── DemoPuntos.java        # Demo/prueba manual (NO es el Main de JavaFX)
    │       ├── modelo/
    │       │   ├── Estudiante.java
    │       │   ├── Objeto.java
    │       │   ├── Recompensa.java
    │       │   ├── MovimientoPuntos.java
    │       │   ├── CategoriaObjeto.java
    │       │   ├── ValorObjeto.java
    │       │   └── EstadoObjeto.java
    │       └── servicio/
    │           ├── ServicioPuntos.java
    │           └── ServicioRecompensas.java
    └── front/
        └── styles/                    # (vacío, para CSS de JavaFX del equipo)
```

Paquete raíz de este módulo: **`back.puntos`** (sub-paquetes `modelo` y
`servicio`). Se eligió `back.puntos.*` en vez de `back.*` directamente
para que, cuando tus compañeros agreguen sus propios paquetes (por
ejemplo `back.usuarios`, `back.reportes`, `back.fotos`), no haya
colisión de nombres de clases entre módulos.

## Reglas de puntos

| Acción                                   | Puntos                                   |
|-------------------------------------------|-------------------------------------------|
| Ver un objeto (primera vez)               | 1                                          |
| Registrar un objeto (perdido/encontrado)  | 5                                          |
| Devolver un objeto perdido                | 20 base + bonificación según valor        |
| &nbsp;&nbsp;&nbsp;&nbsp;valor BAJO         | +0  (total 20)                            |
| &nbsp;&nbsp;&nbsp;&nbsp;valor MEDIO        | +15 (total 35)                            |
| &nbsp;&nbsp;&nbsp;&nbsp;valor ALTO         | +40 (total 60)                            |

Constantes públicas en `ServicioPuntos`: `PUNTOS_POR_VER_OBJETO`,
`PUNTOS_POR_REGISTRAR_OBJETO`, `PUNTOS_BASE_POR_DEVOLUCION`.

## Puntos de integración con los otros módulos

- **Fotos**: `Objeto` ya tiene `agregarFoto(String rutaOUrl)` y
  `getFotos()` para que el módulo de fotos guarde ahí las rutas/URLs
  de las imágenes del objeto, sin tener que modificar esta clase.
- **Control de usuarios / login**: `Estudiante` tiene una nota de
  integración en su Javadoc. Cuando exista una clase `Usuario` con
  credenciales y sesión, lo más simple es relacionar `Estudiante` con
  `Usuario` por id/correo, o hacer que `Estudiante` "envuelva" a un
  `Usuario` en vez de duplicar nombre/correo.
- **Reporte de objetos perdidos**: `Objeto` ya maneja el ciclo de vida
  completo (`EstadoObjeto`: REGISTRADO → PERDIDO/ENCONTRADO → DEVUELTO),
  así que el módulo de reportes puede crear instancias de `Objeto`
  directamente y pasárselas a `ServicioPuntos` cuando corresponda
  otorgar puntos.

## Cómo compilar y probar (mientras no existe el `Main` completo del equipo)

Con Maven (una vez el resto del equipo agregue su `Main.java` en `src/`,
esto se ejecuta con `mvn javafx:run`). Para probar solo este módulo sin
JavaFX, se puede compilar y correr `DemoPuntos` directamente:

```bash
find src/back -name "*.java" > sources.txt
javac -d out @sources.txt
java -cp out back.puntos.DemoPuntos
```

## Próximos pasos sugeridos

- Cuando exista `back.usuarios.Usuario`, decidir si `Estudiante`
  lo referencia o lo extiende.
- Agregar un repositorio en memoria o con base de datos para
  `Estudiante` y `Objeto` (por ahora `ServicioPuntos` no persiste nada,
  solo opera sobre los objetos que le pasen).
- Conectar `ServicioPuntos`/`ServicioRecompensas` a los controladores
  de JavaFX (por ejemplo, llamarlos desde el controlador que maneja el
  botón "Marcar como devuelto").
