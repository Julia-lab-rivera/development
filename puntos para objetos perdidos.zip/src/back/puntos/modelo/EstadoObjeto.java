package back.puntos.modelo;

/**
 * Estados posibles del ciclo de vida de un objeto dentro del sistema.
 */
public enum EstadoObjeto {
    REGISTRADO,
    PERDIDO,
    ENCONTRADO,
    DEVUELTO
}
