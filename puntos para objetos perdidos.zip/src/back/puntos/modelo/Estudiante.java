package back.puntos.modelo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Representa a un estudiante de la Sergio dentro del sistema de puntos.
 *
 * Pensada para integrarse fácilmente: no depende de ninguna base de datos
 * ni framework, solo maneja su propio estado en memoria. Otro módulo del
 * repositorio (por ejemplo uno de persistencia) puede envolver esta clase
 * sin necesidad de modificarla.
 *
 * Nota de integración: cuando exista el módulo de control de usuarios
 * (login, sesiones activas, etc.), lo más probable es que ese módulo
 * tenga su propia clase Usuario con credenciales y datos de sesión.
 * En ese caso, esta clase Estudiante se puede relacionar con Usuario
 * por su id/correo, o Estudiante puede pasar a "envolver" un Usuario
 * (composición) en vez de duplicar campos como nombre o correo.
 */
public class Estudiante {

    private final String id;
    private final String nombre;
    private final String correo;
    private int puntosTotales;
    private final List<MovimientoPuntos> historialPuntos = new ArrayList<>();

    public Estudiante(String id, String nombre, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
        this.puntosTotales = 0;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public int getPuntosTotales() {
        return puntosTotales;
    }

    public List<MovimientoPuntos> getHistorialPuntos() {
        return Collections.unmodifiableList(historialPuntos);
    }

    /**
     * Suma puntos y deja constancia del movimiento en el historial.
     * Este método solo debería ser invocado por la capa de servicio
     * (ServicioPuntos), no directamente desde la UI u otros módulos.
     */
    public void otorgarPuntos(int puntos, String descripcion) {
        if (puntos <= 0) {
            throw new IllegalArgumentException("Los puntos otorgados deben ser positivos");
        }
        this.puntosTotales += puntos;
        this.historialPuntos.add(new MovimientoPuntos(puntos, descripcion));
    }

    /**
     * Descuenta puntos, por ejemplo al canjear una recompensa.
     */
    public void descontarPuntos(int puntos, String descripcion) {
        if (puntos <= 0) {
            throw new IllegalArgumentException("Los puntos a descontar deben ser positivos");
        }
        if (puntos > this.puntosTotales) {
            throw new IllegalStateException("El estudiante no tiene puntos suficientes");
        }
        this.puntosTotales -= puntos;
        this.historialPuntos.add(new MovimientoPuntos(-puntos, descripcion));
    }

    @Override
    public String toString() {
        return String.format("%s (%s) - %d puntos", nombre, id, puntosTotales);
    }
}
